Instructions
============

Place 32-bit PHP Windows binaries into this directory to bundle 32-bit PHP with the application for Windows.

Configure `php.ini` according to the application's needs.

Note that there are restrictions within 32-bit PHP such as poor support for files larger than 2GB.

Even though 32-bit PHP will run on all Windows OSes, using 64-bit PHP with 64-bit Windows is highly recommended.
