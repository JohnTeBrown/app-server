#!/bin/sh

echo "Running uninstaller...";
php install-support/uninstall.php
