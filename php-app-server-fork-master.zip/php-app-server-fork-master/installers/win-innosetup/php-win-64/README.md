Instructions
============

Place 64-bit PHP Windows binaries into this directory to bundle 64-bit PHP with the application for Windows.

Configure `php.ini` according to the application's needs.

Note that 64-bit PHP will only install and run on 64-bit Windows.  When supporting 32-bit Windows OSes, also place 32-bit PHP into the `php-win-32` directory.
